package Reloj_con_mas_clases;

public class CrearReloj {
    public static Reloj crearRelojPredeterminado() {
        return new Reloj(23, 59, 50);
    }
}