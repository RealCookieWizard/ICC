package Reloj_con_mas_clases;

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.mostrarMenu();
    }
}
