package Reloj_con_mas_clases;

import Reloj_con_mas_clases.interfaz.Menu;

public class Main {
    public static void main(String[] args) {
        Menu menu = new Menu();
        menu.mostrarMenu();
    }
}
