package Reloj_con_mas_clases.componentes;

public class Esfera {
    public void mostrarHora(Reloj reloj) {
        System.out.println("Hora actual: " + reloj.obtenerHora());
    }
}
