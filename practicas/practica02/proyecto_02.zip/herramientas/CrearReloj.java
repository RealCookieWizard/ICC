package Reloj_con_mas_clases.herramientas;

import Reloj_con_mas_clases.componentes.Reloj;

public class CrearReloj {
    public static Reloj crearRelojPredeterminado() {
        return new Reloj(23, 59, 50);
    }
}