package Reloj_con_mas_clases.interfaz;

public class Consola {
    public static void imprimir(String mensaje) {
        System.out.println(mensaje);
}
}